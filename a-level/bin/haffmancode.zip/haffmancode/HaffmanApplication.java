package haffmancode;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;

public class HaffmanApplication {
    public static void main(String[] args)throws FileNotFoundException{
        String inputFile = "src/haffmancode/input.txt";
        long startTime = System.currentTimeMillis();
        new HaffmanCode().compressData(inputFile);
        //System.out.println(Arrays.toString(new Node.LeafNode().getCodeTable().toArray()));
        //new Node.LeafNode().printCodeTable();
        long finishTime = System.currentTimeMillis();
        System.out.println(finishTime - startTime + " ms");
    }
}
