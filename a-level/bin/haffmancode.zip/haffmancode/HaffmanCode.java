package haffmancode;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class HaffmanCode {
    public void compressData(String fName) throws FileNotFoundException {
        String outputFile = "src/haffmancode/compressed.txt";
        String readString;
        IOtoFile ioToFile = new IOtoFile();
        List<String> initData = ioToFile.inputStringsFromFile(fName);
        Map<Character, Integer> count = new HashMap<>();
        for (int k = 0; k < initData.size(); k++) {
            readString = initData.get(k);
            for (int i = 0; i < readString.length(); i++) {
                char readChar = readString.charAt(i);
                if (count.containsKey(readChar)) {
                    count.put(readChar, count.get(readChar) + 1);
                } else {
                    count.put(readChar, 1);
                }
            }
        }
        //System.out.println(count.toString()); It's a tested line
        Map<Character, Node> charNodes = new HashMap<>();
        PriorityQueue<Node> priorityQueue = new PriorityQueue<>();
        for (Map.Entry<Character, Integer> entry : count.entrySet()) {
            Node.LeafNode node = new Node.LeafNode(entry.getKey(), entry.getValue());
            charNodes.put(entry.getKey(), node);
            priorityQueue.add(node);
        }
        int sum = 0;
        while (priorityQueue.size() > 1) {
            Node first = priorityQueue.poll();
            Node second = priorityQueue.poll();
            Node.InternalNode node = new Node.InternalNode(first, second);
            sum += node.getSum();
            priorityQueue.add(node);
        }
        if (count.size() == 1) {
            //sum = readString.length();
            sum = count.get(count.keySet());
            System.out.println(sum);
        }
        //System.out.println(count.size() + " " + sum); //It's a tested line
        Node root = priorityQueue.poll();
        if (count.size() == 1) {
            root.buildCode("0");
        } else {
            root.buildCode("");
        }
        StringBuilder stringBuilder = new StringBuilder();

        for (int k = 0; k < initData.size(); k++) {
            readString = initData.get(k);
            for (int i = 0; i < readString.length(); i++) {
                char readChar = readString.charAt(i);
                stringBuilder.append(charNodes.get(readChar).getCode());
            }
        }
        System.out.println(stringBuilder.toString());
        ioToFile.outputStringToFile(stringBuilder.toString(), outputFile);
    }
}